#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST.json"

if not MANIFEST.exists():
    raise SystemExit("MANIFEST.json is missing")
manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))

for relative, record in manifest["files"].items():
    path = ROOT / relative
    if not path.exists():
        raise SystemExit(f"missing file: {relative}")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != record["sha256"]:
        raise SystemExit(
            f"SHA-256 mismatch for {relative}: {digest} != {record['sha256']}"
        )
    if path.stat().st_size != record["bytes"]:
        raise SystemExit(f"size mismatch for {relative}")

claims = json.loads((ROOT / "paper_claims.json").read_text(encoding="utf-8"))
reduced = json.loads(
    (ROOT / "reports/reduced_weight2_normal_form_report.json").read_text(
        encoding="utf-8"
    )
)
sharp = json.loads(
    (ROOT / "reports/hunter_bound1_sharpness_n6_report.json").read_text(
        encoding="utf-8"
    )
)
preimage = json.loads(
    (ROOT / "reports/preimage_chain_bound_n6_report.json").read_text(
        encoding="utf-8"
    )
)
matching = json.loads(
    (ROOT / "reports/preimage_component_matching_report.json").read_text(
        encoding="utf-8"
    )
)
edgecases = json.loads(
    (ROOT / "reports/revision_edge_cases_report.json").read_text(
        encoding="utf-8"
    )
)
full = json.loads(
    (ROOT / "reports/full_primitive_block_stability_report.json").read_text(
        encoding="utf-8"
    )
)
selfnest = json.loads(
    (ROOT / "reports/self_nesting_bridge_macro_theory_report.json").read_text(
        encoding="utf-8"
    )
)

assert reduced["status"] == "PASS"
assert sharp["Bound1"] == 863
assert preimage["bound1_sharp_X"]["PairGap"] == 6
assert preimage["houston_872"]["PairGap"] == 0
assert matching["status"] == "PASS"
assert matching["coverage"] == {
    "all_S3_Hamilton_paths": 720,
    "archived_S4_witnesses": 19,
    "deterministic_random_S4_paths": 4096,
    "random_seed": 20260803,
}
assert edgecases["status"] == "PASS"
assert edgecases["rate_defect_domain"]["order_five_spanning_path_scalars"]["signed_deviation"] == -17
assert edgecases["k5_bridge_ambiguity"]["count"] == 3
pointwise = {
    str(row["k"]): row["candidate_bound"]
    for row in full["pointwise_table"]
}
assert pointwise == {
    "5": 153,
    "6": 869,
    "7": 5892,
    "8": 46118,
    "9": 408418,
    "10": 4033080,
    "11": 43916235,
    "12": 522610764,
    "13": 6746523219,
    "14": 93890256441,
}
assert selfnest["houston_872"]["self_nested_chains"] == 25
assert claims["numerical_lower_bounds"] == pointwise

print(
    json.dumps(
        {
            "status": "PASS",
            "mode": "manifest-and-report",
            "artifact_version": claims["artifact_version"],
            "numerical_lower_bounds": claims["numerical_lower_bounds"],
            "order_six": claims["order_six"],
        },
        ensure_ascii=False,
        indent=2,
    )
)
