# Reproducibility record

## Verification layers

### Lean formalization

- Lean: `4.31.0`
- Repository: `https://github.com/Haruhiyuki/superpermutations-preimage-chain-lower-bounds`
- Formalization source snapshot: `a3852f0de2d84b99cc65d4c281e86892b5f6e911`
- Hunter–Raudvere baseline: `d45222190031d162feb1f6f3cf5fe2d11fab726d`
- Gain-one comparison source: `62958c6268f728828ed578a171486866b6fe4b20`
- Rehashed build: `Build completed successfully (8714 jobs)`
- Final axioms: `propext`, `Classical.choice`, `Quot.sound`
- Active `sorry`, `admit`, project-local `axiom`: none

Canonical commands:

```bash
lake --rehash build
lake env lean AxiomCheck.lean
rg -n '\bsorry\b|\badmit\b|^\s*axiom\b' \
  --glob '*.lean' --glob '!vendor/**' --glob '!proof-progress/**' .
```

The exact logs used for the release record are stored under `formalization/logs/`.

### Deterministic Python audit

- CPython 3.13.5
- Linux x86_64, kernel 6.12.13
- Third-party Python packages: none
- External SAT/MILP/SMT solvers: none
- Floating-point optimization: none

From the supplement root:

```bash
python run_quick_audit.py
python run_full_audit.py
```

The full audit executes the seven checkers in `code/`, regenerates their JSON reports in a temporary directory, compares them byte-for-byte with `reports/`, and then checks the manifest and headline values.

## Division of responsibility

| Layer | Role |
|---|---|
| Pinned Hunter–Raudvere Lean library | Definitions, actual image class, Hunter lower-bound infrastructure, and other external inputs listed in `docs/EXTERNAL_BASELINE.md`. |
| New Lean development | Actual component capacity, primitive-block stability, pointwise actual-image baseline, root-biased layer bookkeeping, capacity-one portal payment, reduced and unconditional pathwise bounds, global superpermutation theorem, and direct `k=5,…,14` corollaries. |
| Deterministic Python audit | Independent finite checks of certificates, local transcriptions, small-order matching, and exact integer tables. |
| Human-readable manuscript | Mathematical exposition, definitions, interpretation, and method limitations. |

A successful Python reconstruction ends with:

```json
{"status": "PASS", "mode": "full reconstruction"}
```
