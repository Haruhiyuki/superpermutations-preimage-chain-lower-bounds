# External Lean 4 baseline and completed project layer

## Pinned Hunter–Raudvere baseline

- Repository: `urdvr/superpermutations-hunter`
- Commit: `d45222190031d162feb1f6f3cf5fe2d11fab726d`
- Lean toolchain: `leanprover/lean4:v4.31.0`
- mathlib revision: `v4.31.0`
- License: Apache-2.0

The manuscript uses the baseline definitions of the genuine superpermutation minimum, the Hamilton-path bridge, the Hunter transform and actual image class, the spanning strongly-exitless characterization, Hunter Bound 1 and pointwise component reduction, and the local triangle-equality surgery.

## New completed formal layer

- Repository: `https://github.com/Haruhiyuki/superpermutations-preimage-chain-lower-bounds`
- Formalization source snapshot: `a3852f0de2d84b99cc65d4c281e86892b5f6e911`
- Lean: `4.31.0`

The new formal layer proves the arbitrary-order component capacity, endpoint rigidity, primitive-block stability, pointwise actual-image baseline, layer budget, portal lower bound, high-entry absorber bound, capacity-one portal payment in both terminal cases, unconditional pathwise theorem, global `Ssuper` theorem, and direct numerical corollaries.

## Comparison upper bound

- Repository: `urdvr/superpermutation-examples`
- Commit: `62958c6268f728828ed578a171486866b6fe4b20`

That source contains the formally checked gain-one lift for all degrees `n ≥ 8`.
