# Claim-to-verification map

| Manuscript item | Verified status | Formal theorem / audit |
|---|---|---|
| Hunter transform, actual image class, pointwise component input | Pinned external Lean 4.31.0 development | Hunter commit `d45222190031d162feb1f6f3cf5fe2d11fab726d` |
| Global `sigma^2`-reduced normal form | Lean formalized | `sigma2_reduced_normal_form`; finite word audit in `verify_reduced_weight2_normal_form.py` |
| Preimage-chain source/target component matching | Lean formalized | actual source and target equivalences; finite independent audit in `verify_preimage_component_matching.py` |
| Exact preimage-chain identity and route-cost budget | Lean formalized | `actual_preimage_chain_identity_components`, `actualBaseline_add_actualPathPaymentCore_le` |
| Actual interval-piece chain capacity | Lean formalized | `actualExactWeightThreeChain_capacity`, `actual_component_capacity` |
| Primitive-block stability and nonnegative non-distinguished defect | Lean formalized | `actual_component_block_stability`, `actual_component_block_affine` |
| Pointwise actual-image Hunter baseline and canonical layer | Lean formalized | `actual_baseline_ge_hunterPath`, `actualBaseline_eq_hunterPath_add_layer` |
| Distinguished-component envelope and portal count | Lean formalized | `actual_distinguished_component_weighted_core`, `actual_zClosed_le_portalCount_core` |
| High-entry absorber bound | Lean formalized | `card_highEntry_le_K_div_E_core` |
| Single global source/terminal exception and paid distinguished target | Lean formalized | `nondistinguishedPortalCountCore_sub_one_le_sources`, no-terminal and terminal payment modules |
| Reduced pathwise lower bound | Lean formalized | `actual_reduced_pathwise_bound_closed` |
| Unconditional pathwise lower bound | Lean formalized | `pathwise_new_bound_closed` |
| Global superpermutation lower bound | Lean formalized | `superperm_new_bound_closed` |
| Numerical lower bounds for `k=5,…,14` | Lean formalized and independently audited | `superperm_numerical_bounds_closed`; `verify_full_primitive_block_stability.py` |
| Order-six `B1=863` image and `Pi=6` | Finite certificate plus formal external image-class input | `verify_hunter_bound1_sharpness_n6.py`, `verify_preimage_chain_bound_n6.py` |
| Two-block bridge obstruction and neutral refinement | Mathematical proof; finite construction audit where applicable | `verify_revision_edge_cases.py`; manuscript proof |
