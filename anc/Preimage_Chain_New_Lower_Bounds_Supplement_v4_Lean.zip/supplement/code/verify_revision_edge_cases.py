#!/usr/bin/env python3
r"""Finite transcription audit for two issues fixed in revision v3.

1. Rate defect is nonnegative only for non-spanning components.  The scalar
   data of the classical order-five spanning path give signed deviation -17.
2. The partial-to-first-full transition in the bridge construction is not
   unique at k=5.  The unified bridge theorem is therefore stated only for
   k>=8 and uses an explicit first-full start.  This checker audits that
   explicit construction for k=8,...,14.

The arbitrary-order bridge proof remains a traditional proof in the paper.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
from typing import Any


def rotate(word: tuple[int, ...], amount: int = 1) -> tuple[int, ...]:
    amount %= len(word)
    return word[amount:] + word[:amount]


def canonical_rotation(word: tuple[int, ...]) -> tuple[int, ...]:
    return min(rotate(word, i) for i in range(len(word)))


def overlap_weight(source: tuple[int, ...], target: tuple[int, ...]) -> int:
    n = len(source)
    for dropped in range(1, n + 1):
        if source[dropped:] == target[:n-dropped]:
            return dropped
    raise AssertionError('empty overlap must work')


def piece_support(start: tuple[int, ...], size: int) -> frozenset[tuple[int, ...]]:
    marker = start[-1]
    base = start[:-1]
    return frozenset(
        canonical_rotation((marker,) + rotate(base, offset))
        for offset in range(size)
    )


def piece_endpoint(start: tuple[int, ...], size: int) -> tuple[int, ...]:
    return (start[-1],) + rotate(start[:-1], size - 1)


def full_Q(start: tuple[int, ...]) -> tuple[int, ...]:
    # start = Y a m, |Y|=k-2
    return rotate(start[:-2], 1) + start[-2:]


def first_full(base: tuple[int, ...], marker: int) -> tuple[int, ...]:
    n = len(base)
    return (
        base[n-1],
        *base[:n-3],
        base[n-2],
        base[n-3],
        marker,
    )


def theta_base(base: tuple[int, ...]) -> tuple[int, ...]:
    n = len(base)
    return (
        base[n-4],
        base[n-2],
        base[n-1],
        *base[:n-4],
        base[n-3],
    )


def bridge_block(base: tuple[int, ...], marker: int) -> dict[str, Any]:
    k = len(base) + 1
    starts = [base + (marker,)]
    sizes = [k - 3]

    z = first_full(base, marker)
    starts.append(z)
    sizes.append(k - 1)
    for _ in range(k - 5):
        z = full_Q(z)
        starts.append(z)
        sizes.append(k - 1)

    if sizes != [k - 3] + [k - 1] * (k - 4):
        raise AssertionError('bridge piece-size drift')

    support: set[tuple[int, ...]] = set()
    for index, (start, size) in enumerate(zip(starts, sizes)):
        local = piece_support(start, size)
        if support & local:
            raise AssertionError(('bridge internal support overlap', k, index))
        support.update(local)
        if index:
            previous_head = piece_endpoint(starts[index-1], sizes[index-1])
            if overlap_weight(previous_head, start) != 3:
                raise AssertionError(('bridge seam is not W3', k, index))

    return {
        'starts': starts,
        'sizes': sizes,
        'support': frozenset(support),
        'head': piece_endpoint(starts[-1], sizes[-1]),
    }


def k5_ambiguity() -> dict[str, Any]:
    k = 5
    start = tuple(range(k))
    size = 2
    endpoint = piece_endpoint(start, size)
    source_support = piece_support(start, size)
    candidates = []
    for tail in itertools.permutations(endpoint[:3]):
        target = endpoint[3:] + tail
        if overlap_weight(endpoint, target) != 3:
            continue
        if source_support.isdisjoint(piece_support(target, 4)):
            candidates.append(target)
    expected = {
        (3, 0, 1, 4, 2),
        (3, 0, 2, 4, 1),
        (3, 0, 2, 1, 4),
    }
    if set(candidates) != expected:
        raise AssertionError(('k=5 ambiguity drift', candidates))
    return {
        'start': list(start),
        'partial_size': size,
        'support_disjoint_W3_full_successors': [list(x) for x in sorted(candidates)],
        'count': len(candidates),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()

    signed_deviation = 11 * 149 - 69 * 24
    if signed_deviation != -17:
        raise AssertionError('spanning signed deviation drift')

    bridge_rows = []
    for k in range(8, 15):
        marker = k - 1
        base = tuple(range(k - 1))
        source = bridge_block(base, marker)
        target_base = theta_base(base)
        target = bridge_block(target_base, marker)
        seam = overlap_weight(source['head'], target_base + (marker,))
        if seam != 3:
            raise AssertionError(('macro bridge seam drift', k, seam))
        if source['support'] & target['support']:
            raise AssertionError(('two bridge supports overlap', k))
        Pk = k*k - 4*k + 1
        if len(source['support']) != Pk:
            raise AssertionError(('bridge support size drift', k))
        bridge_rows.append({
            'k': k,
            'piece_sizes': source['sizes'],
            'block_support_size': len(source['support']),
            'macro_seam_weight': seam,
            'two_block_support_size': len(source['support'] | target['support']),
            'supports_disjoint': True,
        })

    report = {
        'status': 'PASS',
        'rate_defect_domain': {
            'order_five_spanning_path_scalars': {
                'D5': 11,
                'A5': 69,
                't': 24,
                'pValue': 149,
                'signed_deviation': signed_deviation,
            },
            'conclusion': 'nonnegative rate defect is restricted to non-spanning components',
        },
        'k5_bridge_ambiguity': k5_ambiguity(),
        'explicit_bridge_construction_k8_to_k14': bridge_rows,
        'proof_status': {
            'arbitrary_k_statements': 'traditional proof in manuscript',
            'finite_transcription_audit': 'PASS',
            'Lean_formalization': False,
        },
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + '\n', encoding='utf-8')
    print(json.dumps({
        'status': 'PASS',
        'k5_successors': report['k5_bridge_ambiguity']['count'],
        'bridge_orders': [row['k'] for row in bridge_rows],
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
