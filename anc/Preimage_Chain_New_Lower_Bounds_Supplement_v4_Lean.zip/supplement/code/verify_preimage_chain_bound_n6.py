#!/usr/bin/env python3
"""
Independent standard-library verifier for the preimage-chain strengthening of
Hunter Bound 1 at n=6.

Finite checks:
  * reconstruct F(P), the S(P)-chain digraph and the exact preimage-gap
    identity for all 19 archived n=4 cut-profile Hamilton paths;
  * verify PairGap(X) <= the exact gap for all 19 paths;
  * verify the eight-component Bound-1-sharp certificate, B1(X)=863;
  * compute its exact relaxed preimage-chain penalty:
        Pi_0(X)=6, Pi_1(X)=7, PairGap(X)=6;
    hence every Hamiltonian preimage of this X has path weight at least 869;
  * reconstruct Houston's 872 path and verify:
        B1(F(P))=866, exact gap=0, PairGap(F(P))=0,
    so the strengthened bound remains sharp on the known record construction.

The general preimage-chain identity and relaxation theorem are proved
mathematically in the accompanying note. This program verifies the finite
certificates and calibration examples; it is not a proof-assistant
formalization of the general theorem.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import heapq
import itertools
import json
import math
from pathlib import Path
from typing import Any

HOUSTON_872 = '12345612345162345126345123645132645136245136425136452136451234651234156234152634152364152346152341652341256341253641253461253416253412653412356412354612354162354126354123654132654312645316243516243156243165243162543162453164253146253142653142563142536142531645231465231456231452631452361452316453216453126435126431526431256432156423154623154263154236154231654231564213564215362415362145362154362153462135462134562134652134625134621536421563421653421635421634521634251634215643251643256143256413256431265432165432615342613542613452613425613426513426153246513246531246351246315246312546321546325146325416325461325463124563214563241563245163245613245631246532146532416532461532641532614532615432651436251436521435621435261435216435214635214365124361524361254361245361243561243651423561423516423514623514263514236514326541362541365241356241352641352461352416352413654213654123'
INF = 10**9


def rotate(word: tuple[int, ...], amount: int = 1) -> tuple[int, ...]:
    amount %= len(word)
    return word[amount:] + word[:amount]


def rho(word: tuple[int, ...]) -> tuple[int, ...]:
    return rotate(word, 1)


def rho_inv(word: tuple[int, ...]) -> tuple[int, ...]:
    return rotate(word, -1)


def canonical_rotation(word: tuple[int, ...]) -> tuple[int, ...]:
    return min(rotate(word, amount) for amount in range(len(word)))


def overlap_weight(
    source: tuple[int, ...], target: tuple[int, ...]
) -> int:
    n = len(source)
    for dropped in range(1, n + 1):
        if source[dropped:] == target[: n - dropped]:
            return dropped
    raise AssertionError("the empty overlap must always work")


def path_from_word(word: str, n: int) -> tuple[tuple[int, ...], ...]:
    symbols = set(str(index) for index in range(1, n + 1))
    seen: set[tuple[int, ...]] = set()
    path: list[tuple[int, ...]] = []
    for start in range(len(word) - n + 1):
        window = word[start : start + n]
        if len(set(window)) != n or set(window) != symbols:
            continue
        permutation = tuple(int(character) - 1 for character in window)
        if permutation not in seen:
            seen.add(permutation)
            path.append(permutation)
    if len(path) != math.factorial(n):
        raise AssertionError(
            f"expected {math.factorial(n)} permutations, found {len(path)}"
        )
    return tuple(path)


def reconstruct_F(
    path: tuple[tuple[int, ...], ...]
) -> dict[str, Any]:
    n = len(path[0])
    universe = tuple(itertools.permutations(range(n)))
    universe_set = set(universe)
    if len(path) != math.factorial(n) or set(path) != universe_set:
        raise AssertionError("input is not a Hamiltonian path on S_n")

    position = {vertex: index for index, vertex in enumerate(path)}
    path_edges = {
        (path[index], path[index + 1])
        for index in range(len(path) - 1)
    }

    cycles: dict[
        tuple[int, ...], list[tuple[int, ...]]
    ] = collections.defaultdict(list)
    for vertex in universe:
        cycles[canonical_rotation(vertex)].append(vertex)

    C0: set[tuple[int, ...]] = set()
    Cm1: set[tuple[int, ...]] = set()
    for cycle in cycles.values():
        first = min(cycle, key=position.get)
        C0.add(first)
        predecessor = next(vertex for vertex in cycle if rho(vertex) == first)
        Cm1.add(predecessor)

    S = {
        vertex
        for vertex in universe
        if vertex not in Cm1
        and (vertex, rho(vertex)) not in path_edges
    }
    E1 = {edge for edge in path_edges if edge[0] in S}
    added = {(vertex, rho(vertex)) for vertex in S}
    step1 = (path_edges - E1) | added
    indegree = collections.Counter(target for _, target in step1)
    doubles = {vertex for vertex, degree in indegree.items() if degree == 2}
    E2 = {edge for edge in path_edges if edge[1] in doubles}
    X = step1 - E2

    outgoing: dict[
        tuple[int, ...], list[tuple[int, ...]]
    ] = collections.defaultdict(list)
    incoming: dict[
        tuple[int, ...], list[tuple[int, ...]]
    ] = collections.defaultdict(list)
    undirected: dict[
        tuple[int, ...], set[tuple[int, ...]]
    ] = collections.defaultdict(set)

    for source, target in X:
        outgoing[source].append(target)
        incoming[target].append(source)
        undirected[source].add(target)
        undirected[target].add(source)

    components = []
    component_of: dict[tuple[int, ...], int] = {}
    seen: set[tuple[int, ...]] = set()

    for vertex in universe:
        if vertex in seen:
            continue
        stack = [vertex]
        seen.add(vertex)
        component: set[tuple[int, ...]] = set()
        while stack:
            current = stack.pop()
            component.add(current)
            for neighbour in undirected[current]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    stack.append(neighbour)

        tails = [item for item in component if not incoming[item]]
        heads = [item for item in component if not outgoing[item]]
        if len(tails) != 1 or len(heads) != 1:
            raise AssertionError(
                ("F(P) component is not a directed path", tails, heads)
            )

        edges = [edge for edge in X if edge[0] in component]
        tail = tails[0]
        head = heads[0]
        if len(component) == len(universe):
            minto = 0
        else:
            minto = min(
                overlap_weight(outside, tail)
                for outside in universe
                if outside not in component
            )

        index = len(components)
        for item in component:
            component_of[item] = index

        components.append(
            {
                "vertices": component,
                "tail": tail,
                "head": head,
                "edges": edges,
                "weight": sum(overlap_weight(*edge) for edge in edges),
                "minto": minto,
                "size": len(component),
            }
        )

    if set(component_of) != universe_set:
        raise AssertionError("F(P) components do not span S_n")

    B1 = (
        len(components)
        - 1
        + sum(component["weight"] for component in components)
        + sum(component["minto"] for component in components)
        - max(component["minto"] for component in components)
    )

    return {
        "n": n,
        "universe": universe,
        "path": path,
        "position": position,
        "path_edges": path_edges,
        "S": S,
        "E1": E1,
        "E2": E2,
        "X": X,
        "components": components,
        "component_of": component_of,
        "B1": B1,
        "path_weight": sum(
            overlap_weight(path[index], path[index + 1])
            for index in range(len(path) - 1)
        ),
    }


def extract_S_chains(data: dict[str, Any]) -> tuple[
    list[dict[str, Any]], list[list[tuple[int, ...]]]
]:
    path = data["path"]
    S = data["S"]
    components = data["components"]
    component_of = data["component_of"]

    successor = {
        path[index]: path[index + 1]
        for index in range(len(path) - 1)
    }
    predecessor = {
        path[index + 1]: path[index]
        for index in range(len(path) - 1)
    }

    relation: dict[
        tuple[int, ...], tuple[int, ...]
    ] = {}
    indegree: collections.Counter[tuple[int, ...]] = collections.Counter()

    for source in S:
        if source not in successor:
            continue
        candidate = rho_inv(successor[source])
        if candidate in S and rho(candidate) == successor[source]:
            relation[source] = candidate
            indegree[candidate] += 1

    starts = [vertex for vertex in S if indegree[vertex] == 0]
    visited: set[tuple[int, ...]] = set()
    chains = []

    for start in starts:
        slots = []
        current = start
        while current not in visited:
            visited.add(current)
            slots.append(current)
            if current not in relation:
                break
            current = relation[current]

        source_head = predecessor[rho(start)]
        head_component = component_of[source_head]
        if components[head_component]["head"] != source_head:
            raise AssertionError("S-chain does not begin at an X-head")

        end = slots[-1]
        if end == path[-1]:
            tail_component = None
        else:
            target_tail = successor[end]
            tail_component = component_of[target_tail]
            if components[tail_component]["tail"] != target_tail:
                raise AssertionError("S-chain does not end at an X-tail")
            if end in components[tail_component]["vertices"]:
                raise AssertionError(
                    "terminal slot lies inside its target component"
                )

        chains.append(
            {
                "head_component": head_component,
                "tail_component": tail_component,
                "slots": slots,
            }
        )

    cycles = []
    for vertex in S:
        if vertex in visited:
            continue
        cycle = []
        current = vertex
        while current not in visited:
            visited.add(current)
            cycle.append(current)
            current = relation[current]
        cycles.append(cycle)

    if visited != S:
        raise AssertionError("S-chain decomposition did not cover S(P)")
    return chains, cycles


def exact_preimage_gap(data: dict[str, Any]) -> dict[str, Any]:
    components = data["components"]
    path = data["path"]
    chains, cycles = extract_S_chains(data)

    max_minto = max(component["minto"] for component in components)
    first_component = data["component_of"][path[0]]
    root_penalty = max_minto - components[first_component]["minto"]
    indicator = int(path[-1] in data["S"])

    chain_records = []
    gap = root_penalty + indicator

    for chain in chains:
        head_component = chain["head_component"]
        tail_component = chain["tail_component"]
        slots = chain["slots"]

        entry_cost = (
            overlap_weight(
                components[head_component]["head"], rho(slots[0])
            )
            - 2
        )
        internal_cost = sum(
            overlap_weight(slots[index], rho(slots[index + 1])) - 1
            for index in range(len(slots) - 1)
        )

        if tail_component is None:
            exit_cost = 0
        else:
            exit_cost = (
                overlap_weight(
                    slots[-1], components[tail_component]["tail"]
                )
                - components[tail_component]["minto"]
            )

        if min(entry_cost, internal_cost, exit_cost) < 0:
            raise AssertionError("negative exact chain contribution")

        chain_cost = entry_cost + internal_cost + exit_cost
        gap += chain_cost
        chain_records.append(
            {
                "head_component": head_component,
                "tail_component": tail_component,
                "slot_count": len(slots),
                "entry_cost": entry_cost,
                "internal_cost": internal_cost,
                "exit_cost": exit_cost,
                "total": chain_cost,
            }
        )

    cycle_costs = []
    for cycle in cycles:
        cost = sum(
            overlap_weight(cycle[index], rho(cycle[(index + 1) % len(cycle)]))
            - 1
            for index in range(len(cycle))
        )
        if cost < 0:
            raise AssertionError("negative S-cycle contribution")
        gap += cost
        cycle_costs.append(cost)

    actual_gap = data["path_weight"] - data["B1"]
    if actual_gap != gap:
        raise AssertionError(
            ("exact preimage-chain identity failed", actual_gap, gap)
        )

    return {
        "actual_gap": actual_gap,
        "identity_value": gap,
        "root_penalty": root_penalty,
        "indicator": indicator,
        "chains": chain_records,
        "cycle_costs": cycle_costs,
    }


def hungarian(cost: list[list[int]]) -> tuple[int, list[int]]:
    """Minimum-cost assignment for a square integer matrix."""
    n = len(cost)
    if n == 0:
        return 0, []

    u = [0] * (n + 1)
    v = [0] * (n + 1)
    p = [0] * (n + 1)
    way = [0] * (n + 1)

    for row in range(1, n + 1):
        p[0] = row
        column0 = 0
        min_value = [INF] * (n + 1)
        used = [False] * (n + 1)

        while True:
            used[column0] = True
            active_row = p[column0]
            delta = INF
            column1 = 0

            for column in range(1, n + 1):
                if used[column]:
                    continue
                reduced = (
                    cost[active_row - 1][column - 1]
                    - u[active_row]
                    - v[column]
                )
                if reduced < min_value[column]:
                    min_value[column] = reduced
                    way[column] = column0
                if min_value[column] < delta:
                    delta = min_value[column]
                    column1 = column

            for column in range(n + 1):
                if used[column]:
                    u[p[column]] += delta
                    v[column] -= delta
                else:
                    min_value[column] -= delta

            column0 = column1
            if p[column0] == 0:
                break

        while True:
            column1 = way[column0]
            p[column0] = p[column1]
            column0 = column1
            if column0 == 0:
                break

    assignment = [-1] * n
    for column in range(1, n + 1):
        assignment[p[column] - 1] = column - 1

    return -v[0], assignment


def shortest_slot_costs(
    components: list[dict[str, Any]],
    X: set[tuple[tuple[int, ...], tuple[int, ...]]],
) -> dict[str, Any]:
    slots = [source for source, target in X if target == rho(source)]
    slot_targets = [rho(slot) for slot in slots]
    slot_count = len(slots)

    internal = [[0] * slot_count for _ in range(slot_count)]
    for left, source in enumerate(slots):
        for right, target in enumerate(slot_targets):
            if left == right:
                internal[left][right] = INF
            else:
                cost = overlap_weight(source, target) - 1
                if cost < 1:
                    raise AssertionError("distinct-slot internal cost is not positive")
                internal[left][right] = cost

    pair = [[INF] * len(components) for _ in components]
    special = [INF] * len(components)
    shortest_sequences: dict[tuple[int, int | None], list[int]] = {}

    for head_index, component in enumerate(components):
        distance = [
            overlap_weight(component["head"], target) - 2
            for target in slot_targets
        ]
        if min(distance) < 0:
            raise AssertionError("negative slot-entry cost")
        parent = [-1] * slot_count

        # Dense Dijkstra. All internal costs are positive.
        used = [False] * slot_count
        for _ in range(slot_count):
            current = -1
            best = INF
            for index in range(slot_count):
                if not used[index] and distance[index] < best:
                    best = distance[index]
                    current = index
            if current < 0:
                break
            used[current] = True

            for target_index in range(slot_count):
                candidate = best + internal[current][target_index]
                if candidate < distance[target_index]:
                    distance[target_index] = candidate
                    parent[target_index] = current

        special_end = min(range(slot_count), key=distance.__getitem__)
        special[head_index] = distance[special_end]

        def recover(end_index: int) -> list[int]:
            sequence = []
            current = end_index
            while current >= 0:
                sequence.append(current)
                current = parent[current]
            sequence.reverse()
            return sequence

        shortest_sequences[(head_index, None)] = recover(special_end)

        for tail_index, tail_component in enumerate(components):
            candidates = [
                (
                    distance[index]
                    + overlap_weight(slots[index], tail_component["tail"])
                    - tail_component["minto"],
                    index,
                )
                for index in range(slot_count)
                if slots[index] not in tail_component["vertices"]
            ]
            if not candidates:
                # This occurs only when the target component is the entire
                # universe (the one-component case).  No ordinary chain may
                # terminate there from an outside slot; the I=0 matching also
                # omits the unique root tail, so INF is the correct convention.
                pair[head_index][tail_index] = INF
                shortest_sequences[(head_index, tail_index)] = []
                continue
            cost, end_index = min(candidates)
            if cost < 0:
                raise AssertionError("negative head-to-tail chain cost")
            pair[head_index][tail_index] = cost
            shortest_sequences[(head_index, tail_index)] = recover(end_index)

    return {
        "slots": slots,
        "pair": pair,
        "special": special,
        "shortest_sequences": shortest_sequences,
    }


def pair_gap(
    components: list[dict[str, Any]],
    X: set[tuple[tuple[int, ...], tuple[int, ...]]],
) -> dict[str, Any]:
    costs = shortest_slot_costs(components, X)
    pair = costs["pair"]
    special = costs["special"]
    component_count = len(components)
    maximum_minto = max(component["minto"] for component in components)

    best_zero = (INF, None)
    for root in range(component_count):
        tail_components = [
            index for index in range(component_count) if index != root
        ]
        root_penalty = maximum_minto - components[root]["minto"]

        for last in range(component_count):
            head_components = [
                index for index in range(component_count) if index != last
            ]
            matrix = [
                [pair[head][tail] for tail in tail_components]
                for head in head_components
            ]
            value, assignment = hungarian(matrix)
            value += root_penalty
            if value < best_zero[0]:
                best_zero = (
                    value,
                    {
                        "root_component": root,
                        "last_component": last,
                        "root_penalty": root_penalty,
                        "matching": [
                            {
                                "head_component": head,
                                "tail_component": tail_components[
                                    assignment[row]
                                ],
                                "cost": pair[head][
                                    tail_components[assignment[row]]
                                ],
                            }
                            for row, head in enumerate(head_components)
                        ],
                    },
                )

    best_one = (INF, None)
    for root in range(component_count):
        tail_components = [
            index for index in range(component_count) if index != root
        ]
        root_penalty = maximum_minto - components[root]["minto"]
        matrix = [
            [pair[head][tail] for tail in tail_components]
            + [special[head]]
            for head in range(component_count)
        ]
        value, assignment = hungarian(matrix)
        value += root_penalty + 1

        if value < best_one[0]:
            matching = []
            for head, target_column in enumerate(assignment):
                if target_column == len(tail_components):
                    target = "special"
                    cost = special[head]
                else:
                    target = tail_components[target_column]
                    cost = pair[head][target]
                matching.append(
                    {
                        "head_component": head,
                        "target": target,
                        "cost": cost,
                    }
                )
            best_one = (
                value,
                {
                    "root_component": root,
                    "root_penalty": root_penalty,
                    "indicator_penalty": 1,
                    "matching": matching,
                },
            )

    return {
        "slot_count": len(costs["slots"]),
        "pair_matrix": pair,
        "special_costs": special,
        "Pi0": best_zero[0],
        "Pi1": best_one[0],
        "PairGap": min(best_zero[0], best_one[0]),
        "Pi0_witness": best_zero[1],
        "Pi1_witness": best_one[1],
    }


def verify_strongly_exitless_path(
    path: tuple[tuple[int, ...], ...]
) -> None:
    positions = {vertex: index for index, vertex in enumerate(path)}
    for index, (source, target) in enumerate(zip(path, path[1:])):
        if (
            overlap_weight(source, target) >= 2
            and index < positions.get(rho(source), len(path))
        ):
            raise AssertionError(("early exit", index))
    if rho(path[-1]) not in positions:
        raise AssertionError("path is not strongly exitless")


def sharp_certificate(
    certificate_path: Path,
) -> tuple[list[dict[str, Any]], set[tuple[tuple[int, ...], tuple[int, ...]]]]:
    with gzip.open(certificate_path, "rt", encoding="utf-8") as handle:
        certificate = json.load(handle)

    universe = set(itertools.permutations(range(6)))
    owned: set[tuple[int, ...]] = set()
    components = []
    X = set()

    for record in certificate["components"]:
        path = tuple(tuple(vertex) for vertex in record["path"])
        verify_strongly_exitless_path(path)
        vertices = set(path)
        if owned & vertices:
            raise AssertionError("sharpness certificate components overlap")
        owned |= vertices

        edges = list(zip(path, path[1:]))
        X.update(edges)
        path_weight = sum(overlap_weight(*edge) for edge in edges)
        minto = min(
            overlap_weight(outside, path[0])
            for outside in universe - vertices
        )
        if path_weight != record["weight"] or minto != record["minto"]:
            raise AssertionError("sharpness certificate scalar drift")

        components.append(
            {
                "vertices": vertices,
                "tail": path[0],
                "head": path[-1],
                "edges": edges,
                "weight": path_weight,
                "minto": minto,
                "size": len(path),
            }
        )

    if owned != universe:
        raise AssertionError("sharpness certificate does not span S_6")
    return components, X


def component_B1(components: list[dict[str, Any]]) -> int:
    return (
        len(components)
        - 1
        + sum(component["weight"] for component in components)
        + sum(component["minto"] for component in components)
        - max(component["minto"] for component in components)
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    directory = Path(__file__).resolve().parent
    parser.add_argument(
        "--sharp-certificate",
        type=Path,
        default=directory / "hunter_bound1_sharpness_n6_certificate.json.gz",
    )
    parser.add_argument(
        "--n4-witnesses",
        type=Path,
        default=directory / "n4_cut_profile_witnesses.json.gz",
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    # ---------------------------------------------------------------
    # Finite calibration on all 19 archived n=4 profile witnesses.
    # ---------------------------------------------------------------
    with gzip.open(args.n4_witnesses, "rt", encoding="utf-8") as handle:
        n4_input = json.load(handle)

    n4_rows = []
    for profile in sorted(n4_input, key=int):
        path = tuple(
            tuple(vertex)
            for vertex in n4_input[profile]["path"]
        )
        data = reconstruct_F(path)
        identity = exact_preimage_gap(data)
        relaxed = pair_gap(data["components"], data["X"])

        if relaxed["PairGap"] > identity["actual_gap"]:
            raise AssertionError("PairGap exceeds the exact n=4 gap")

        n4_rows.append(
            {
                "profile": int(profile),
                "path_weight": data["path_weight"],
                "B1": data["B1"],
                "exact_gap": identity["actual_gap"],
                "identity_value": identity["identity_value"],
                "PairGap": relaxed["PairGap"],
                "components": len(data["components"]),
                "S_size": len(data["S"]),
            }
        )

    # ---------------------------------------------------------------
    # Bound-1-sharp eight-component X.
    # ---------------------------------------------------------------
    sharp_components, sharp_X = sharp_certificate(args.sharp_certificate)
    sharp_B1 = component_B1(sharp_components)
    if sharp_B1 != 863:
        raise AssertionError(("sharp B1 drift", sharp_B1))

    sharp_relaxed = pair_gap(sharp_components, sharp_X)
    if (
        sharp_relaxed["Pi0"],
        sharp_relaxed["Pi1"],
        sharp_relaxed["PairGap"],
    ) != (6, 7, 6):
        raise AssertionError(("sharp PairGap drift", sharp_relaxed))

    # ---------------------------------------------------------------
    # Houston 872 calibration.
    # ---------------------------------------------------------------
    houston_path = path_from_word(HOUSTON_872, 6)
    houston = reconstruct_F(houston_path)
    houston_identity = exact_preimage_gap(houston)
    houston_relaxed = pair_gap(houston["components"], houston["X"])

    if houston["path_weight"] != 866 or houston["B1"] != 866:
        raise AssertionError("Houston scalar drift")
    if houston_identity["actual_gap"] != 0:
        raise AssertionError("Houston exact gap is not zero")
    if (
        houston_relaxed["Pi0"],
        houston_relaxed["Pi1"],
        houston_relaxed["PairGap"],
    ) != (0, 1, 0):
        raise AssertionError(("Houston PairGap drift", houston_relaxed))

    if collections.Counter(
        component["size"] for component in houston["components"]
    ) != collections.Counter({24: 25, 120: 1}):
        raise AssertionError("Houston component census drift")

    report = {
        "theorem_under_test": {
            "exact_identity": (
                "w(P)-B1(F(P)) equals the root-minto penalty, the terminal "
                "indicator, all S(P)-chain entry/internal/exit costs, and all "
                "S(P)-cycle costs."
            ),
            "relaxation": (
                "PairGap(X) independently shortest-path-relaxes every S-chain "
                "and minimum-cost-matches component heads to component tails "
                "(plus the I=1 terminal). Therefore "
                "w(P) >= B1(F(P)) + PairGap(F(P))."
            ),
        },
        "n4_calibration": {
            "witnesses": len(n4_rows),
            "exact_identity_passed": all(
                row["exact_gap"] == row["identity_value"]
                for row in n4_rows
            ),
            "relaxed_bound_passed": all(
                row["PairGap"] <= row["exact_gap"]
                for row in n4_rows
            ),
            "rows": n4_rows,
        },
        "bound1_sharp_X": {
            "components": len(sharp_components),
            "component_size_census": dict(
                sorted(
                    collections.Counter(
                        component["size"]
                        for component in sharp_components
                    ).items()
                )
            ),
            "B1": sharp_B1,
            "Pi0": sharp_relaxed["Pi0"],
            "Pi1": sharp_relaxed["Pi1"],
            "PairGap": sharp_relaxed["PairGap"],
            "strengthened_path_lower_bound": (
                sharp_B1 + sharp_relaxed["PairGap"]
            ),
            "strengthened_string_lower_bound": (
                sharp_B1 + sharp_relaxed["PairGap"] + 6
            ),
            "pair_matrix": sharp_relaxed["pair_matrix"],
            "Pi0_witness": sharp_relaxed["Pi0_witness"],
            "Pi1_witness": sharp_relaxed["Pi1_witness"],
        },
        "houston_872": {
            "path_weight": houston["path_weight"],
            "components": len(houston["components"]),
            "component_size_census": dict(
                sorted(
                    collections.Counter(
                        component["size"]
                        for component in houston["components"]
                    ).items()
                )
            ),
            "B1": houston["B1"],
            "exact_preimage_gap": houston_identity["actual_gap"],
            "S_chains": len(houston_identity["chains"]),
            "S_chain_length_histogram": dict(
                sorted(
                    collections.Counter(
                        chain["slot_count"]
                        for chain in houston_identity["chains"]
                    ).items()
                )
            ),
            "S_chain_cost_histogram": dict(
                sorted(
                    collections.Counter(
                        chain["total"]
                        for chain in houston_identity["chains"]
                    ).items()
                )
            ),
            "Pi0": houston_relaxed["Pi0"],
            "Pi1": houston_relaxed["Pi1"],
            "PairGap": houston_relaxed["PairGap"],
            "strengthened_path_lower_bound": (
                houston["B1"] + houston_relaxed["PairGap"]
            ),
            "strengthened_string_lower_bound": (
                houston["B1"] + houston_relaxed["PairGap"] + 6
            ),
        },
        "research_conclusion": (
            "The new functional B_pc(X)=B1(X)+PairGap(X) strictly improves "
            "Hunter Bound 1 on the explicit B1=863 sharpness obstruction "
            "(863 -> 869), while remaining exact on Houston's 872 "
            "construction (866 -> 866). The remaining holy-grail problem is "
            "to prove min_{X in X_6} B_pc(X) >= 866."
        ),
        "proof_status": {
            "general_identity_and_relaxation": (
                "traditional mathematical proof in the accompanying note"
            ),
            "finite_certificates": "independently checked by this program",
            "lean_formalization": False,
            "global_S6_equals_872": False,
        },
    }

    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "PASS",
                "n4_witnesses": len(n4_rows),
                "sharp": {
                    "B1": sharp_B1,
                    "PairGap": sharp_relaxed["PairGap"],
                    "strengthened": sharp_B1 + sharp_relaxed["PairGap"],
                },
                "houston": {
                    "B1": houston["B1"],
                    "PairGap": houston_relaxed["PairGap"],
                    "strengthened": (
                        houston["B1"] + houston_relaxed["PairGap"]
                    ),
                },
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
