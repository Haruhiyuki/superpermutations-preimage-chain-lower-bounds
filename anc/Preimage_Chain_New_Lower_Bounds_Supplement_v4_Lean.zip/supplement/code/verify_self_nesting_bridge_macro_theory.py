#!/usr/bin/env python3
"""
Finite audit for the self-nesting dichotomy and bridge-macro dynamics.

General mathematical statements proved in the accompanying note:

1. Zero-cost single-slot dichotomy.
   For a reduced zero-cost chain from component head h to a minto-2 tail,
   the target tail is forced to
       Psi(h) = tau(sigma^{-1}(tau(h))).
   If [Psi(h)] already belongs to the source component, the target must be
   the source component itself.  This is possible exactly when
       tail(C) = Psi(head(C)).

2. Terminal-full rigidity.
   A simple component whose last interval piece is full can never be
   self-closing.  Consequently every minto-2 terminal-full portal is rigid;
   this supplies the missing self-nesting check in the earlier full
   primitive-block absorption theorem.

3. Self-closing gap.
   A minto-2 self-closing component is either the one-piece attachment atom
   of size k-2 and rate defect k-3, or, if it has at least two pieces, has
   rate defect at least D_k=k^2-3k+1.

4. Bridge macro dynamics.
   The canonical bridge block has piece sizes
       (k-3),(k-1)^(k-4),
   covers P_k=k^2-4k+1 rotation classes, and has rate defect k-1.
   It has a unique incidence-disjoint exact-W3 bridge-block successor.  On
   the base positions n=k-1 the successor map is
       Theta_n=(n-4,n-2,n-1,0,...,n-5,n-3).
   Its permutation order is the explicit lambda_k below.

This verifier checks the finite content, including Houston-872 calibration,
all primitive ladders for 5<=k<=14, exhaustive small self-closing searches,
and bridge macro orbits for 7<=k<=24.  It is not a Lean formalization.
"""
from __future__ import annotations
import argparse, collections, functools, hashlib, importlib.util, itertools, json, math
from pathlib import Path
from typing import Any

BASE_SHA="78d50a07aea292dc74ed3cd6b1fe4ad9849251cb728435a14a72156005545a95"
FULL_SHA="be7bf2e7d8807356d60e55b4f49a12b3d34f72fc6eb0cf961ff61d7d680fd0aa"

def req(x,msg):
    if not x: raise AssertionError(msg)
def sha(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()
def rot(w,a=1):
    w=tuple(w); a%=len(w); return w[a:]+w[:a]
def canon(w): return rot(w,w.index(0))
def rho2(w): return w[2:]+(w[1],w[0])
def rho2inv(w): return (w[-1],w[-2])+w[:-2]
def ow(a,b):
    n=len(a)
    for d in range(1,n+1):
        if a[d:]==b[:n-d]: return d
    raise AssertionError
def psi(h): return rho2(rot(rho2(h),-1))
def D(k): return k*k-3*k+1
def A(k): return k**3-2*k*k-k-1

def load(path:Path,name:str):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec); assert spec.loader
    spec.loader.exec_module(m); return m

def piece_vertices(start,size):
    k=len(start); cur=start; out=[cur]
    for i in range(size):
        for _ in range(k-1): cur=rot(cur); out.append(cur)
        if i+1<size: cur=rho2(cur); out.append(cur)
    return tuple(out)

def primitive(k,d):
    marker=k-1; anchor=k-3
    orbit=tuple(range(k-3))+(k-2,)
    r=k-2-d
    specs=[(tuple(range(k)),k-2)]
    for shift in range(r-1):
        specs.append((rot(orbit,shift)+(anchor,marker),k-1))
    verts=tuple()
    for st,z in specs: verts+=piece_vertices(st,z)
    support={canon(v) for v in verts}; tail=verts[0]; head=verts[-1]
    forced=psi(head)
    return {
      'k':k,'d':d,'pieces':[z for _,z in specs],
      'cycles':len(support),'tail':tail,'head':head,'forced':forced,
      'collision':canon(forced) in support,'selfclosing':forced==tail,
      'simple':len(set(verts))==len(verts),
    }

def pattern_paths(k,sizes):
    ident=tuple(range(k))
    @functools.lru_cache(None)
    def support(st,z):
        m=st[-1]; B=st[:-1]
        return frozenset(canon((m,)+rot(B,i)) for i in range(z))
    @functools.lru_cache(None)
    def end(st,z): return (st[-1],)+rot(st[:-1],z-1)
    @functools.lru_cache(None)
    def succ(st,z):
        e=end(st,z); out=[]
        for p in itertools.permutations(e[:3]):
            ns=e[3:]+p; req(ow(e,ns)==3,'non-W3')
            for nz in range(1,k): out.append((ns,nz))
        return tuple(out)
    ans=[]
    def dfs(i,prev,used,path):
        if i==len(sizes): ans.append(tuple(path)); return
        cand=[(ident,sizes[0])] if i==0 else [x for x in succ(*prev) if x[1]==sizes[i]]
        for x in cand:
            s=support(*x)
            if s&used: continue
            dfs(i+1,x,used|s,path+[x])
    dfs(0,None,frozenset(),[])
    return ans,support,end

def block_base(k):
    full=k-1
    paths,support,end=pattern_paths(k,[k-3]+[full]*(k-4))
    req(len(paths)==1,('bridge block not unique',k,len(paths)))
    path=paths[0]; sup=frozenset().union(*(support(*x) for x in path)); head=end(*path[-1])
    return path,sup,head

def relword(w,lab): return tuple(lab[x] for x in w)
def relsup(s,lab): return frozenset(canon(relword(c,lab)) for c in s)
def block_at(k,start,base):
    path0,sup0,head0=base; lab=start
    return (tuple((relword(st,lab),z) for st,z in path0), relsup(sup0,lab), relword(head0,lab))
def w3starts(h): return [h[3:]+p for p in itertools.permutations(h[:3])]
def theta_start(start):
    B=start[:-1]; m=start[-1]; n=len(B)
    return tuple([B[n-4],B[n-2],B[n-1],*B[:n-4],B[n-3],m])
def lambda_k(k):
    n=k-1
    if n%3==0: return 2*(n//3)
    if n%3==1:
        m=(n-1)//3; return m*(2*m+1)
    m=(n-2)//3; return (m+1)*(2*m+1)
def perm_order(p):
    seen=set(); o=1; cycles=[]
    for i in range(len(p)):
        if i in seen: continue
        c=[]; x=i
        while x not in seen:
            seen.add(x); c.append(x); x=p[x]
        cycles.append(c); o=math.lcm(o,len(c))
    return o,cycles

def bridge_audit(k):
    base=block_base(k); path0,sup0,head0=base
    req(len(sup0)==k*k-4*k+1,'bridge size')
    candidates=[]
    for ns in w3starts(head0):
        _,s2,_=block_at(k,ns,base); candidates.append((ns,len(sup0&s2)))
    dis=[ns for ns,i in candidates if i==0]
    req(dis==[theta_start(tuple(range(k)))],('unique theta',k,dis))
    n=k-1; p=[n-4,n-2,n-1,*range(n-4),n-3]
    order,cycles=perm_order(p); req(order==lambda_k(k),'theta order')
    start=tuple(range(k)); used=frozenset(); prefix=[]; rigid=True
    for q in range(1,order+1):
        path,sup,head=block_at(k,start,base); req(not(sup&used),'macro overlap before order')
        used=used|sup; prefix.extend(path)
        tail=tuple(range(k)); forced=psi(head)
        collision=canon(forced) in used
        req(collision,'bridge collision absent')
        req(forced!=tail,'bridge macro selfcloses')
        # next locally disjoint bridge block is theta(start)
        local=[]
        for ns in w3starts(head):
            _,ss,_=block_at(k,ns,base)
            if not(ss&sup): local.append(ns)
        req(local==[theta_start(start)],'local successor drift')
        if q<order:
            nxt=theta_start(start); _,sn,_=block_at(k,nxt,base)
            req(not(sn&used),'macro orbit cumulative overlap')
            start=nxt
    repeat=theta_start(start)
    # after order applications, repeat is the second state? start is theta^(order-1); theta(start)=identity
    req(repeat==tuple(range(k)),'macro orbit did not close')
    _,repeat_sup,_=block_at(k,repeat,base); req(bool(repeat_sup&used),'repeated block not blocked')
    P=k*k-4*k+1
    return {'k':k,'block_cycles':P,'block_defect':k-1,'lambda':order,
            'theta_cycles':cycles,'candidate_intersections':sorted(i for _,i in candidates),
            'macro_chain_cycles':order*P,'macro_chain_defect':order*(k-1),
            'all_prefixes_rigid':rigid}

def selfclose_exhaustive(k,maxD):
    ident=tuple(range(k)); full=k-1; proper=canon(rho2inv(ident))
    @functools.lru_cache(None)
    def support(st,z):
        m=st[-1];B=st[:-1];return frozenset(canon((m,)+rot(B,i)) for i in range(z))
    @functools.lru_cache(None)
    def end(st,z):return (st[-1],)+rot(st[:-1],z-1)
    @functools.lru_cache(None)
    def succ(st,z):
        e=end(st,z);out=[]
        for p in itertools.permutations(e[:3]):
            ns=e[3:]+p
            for nz in range(1,k):out.append((ns,nz))
        return tuple(out)
    rows=[]; nodes=0
    def dfs(path,used,Delta):
        nonlocal nodes; nodes+=1
        h=end(*path[-1])
        if psi(h)==ident and proper not in used:
            d=(k-2)*Delta-len(path)
            rows.append({'Delta':Delta,'pieces':[z for _,z in path],'rate_defect':d,'atomic':len(path)==1})
        if Delta>=maxD:return
        for x in succ(*path[-1]):
            nd=Delta+full-x[1]
            if nd>maxD:continue
            s=support(*x)
            if s&used:continue
            dfs(path+(x,),used|s,nd)
    for z in range(1,full):
        d=full-z
        if d<=maxD:dfs(((ident,z),),support(ident,z),d)
    req(all((r['atomic'] and r['Delta']==1 and r['rate_defect']==k-3) or
                (not r['atomic'] and r['Delta']>=k and r['rate_defect']>=D(k)) for r in rows),
        ('selfclose gap audit',k,rows))
    return {'k':k,'max_Delta':maxD,'nodes':nodes,'selfclosing_paths':len(rows),'rows':rows}

def houston_audit(base):
    P=base.path_from_word(base.HOUSTON_872,6); data=base.reconstruct_F(P)
    chains,_=base.extract_S_chains(data)
    comp=[]
    for i,c in enumerate(data['components']):
        out={a:b for a,b in c['edges']}; v=c['tail']; arr=[v]
        while v in out: v=out[v];arr.append(v)
        forced=psi(c['head']); collision=canon(forced) in {canon(x) for x in arr}
        # piece sizes
        sizes=[];cur=1
        for a,b in zip(arr,arr[1:]):
            if b==rot(a): continue
            if b==rho2(a): cur+=1
            else: sizes.append(cur);cur=1
        sizes.append(cur)
        comp.append({'index':i,'cycles':len(arr)//6,'minto':c['minto'],'pieces':sizes,
                     'collision':collision,'selfclosing':forced==c['tail']})
    fixed=sum(1 for ch in chains if ch['tail_component']==ch['head_component'])
    req(fixed==25,'Houston fixed-point nesting count')
    req(sum(x['selfclosing'] for x in comp)==25,'Houston selfclose census')
    req(all(x['pieces']==[4] for x in comp if x['selfclosing']),'Houston atom shape')
    return {'components':comp,'zero_cost_chains':len(chains),'self_nested_chains':fixed,'B1':data['B1'],'path_weight':data['path_weight']}

def main():
    ap=argparse.ArgumentParser(); here=Path(__file__).resolve().parent
    ap.add_argument('--base',type=Path,default=here/'verify_preimage_chain_bound_n6.py')
    ap.add_argument('--full-stability',type=Path,default=here/'verify_full_primitive_block_stability.py')
    ap.add_argument('--output',type=Path); args=ap.parse_args()
    req(sha(args.base)==BASE_SHA,'base hash drift'); req(sha(args.full_stability)==FULL_SHA,'full stability hash drift')
    base=load(args.base,'pcbase')
    houston=houston_audit(base)
    primitives=[]
    for k in range(5,15):
        for d in range(k-3):
            row=primitive(k,d); req(row['simple'] and row['collision'] and not row['selfclosing'],'primitive rigidity')
            primitives.append(row)
    selfrows=[selfclose_exhaustive(k,k) for k in range(5,10)]
    bridges=[bridge_audit(k) for k in range(7,25)]
    n14=next(x for x in bridges if x['k']==14)
    result={
      'status':'PASS',
      'general_theorems':{
       'zero_cost_dichotomy':'collision target is distinct-impossible or exact self-nesting',
       'terminal_full_rigidity':'a simple last-full component cannot self-close',
       'self_closing_gap':'atomic A_k has d=k-3; every non-atomic self-closer has d>=D_k',
       'bridge_macro':'unique Theta successor and explicit orbit period lambda_k'
      },
      'hash_bound_dependencies':{'preimage_verifier_sha256':BASE_SHA,'full_stability_verifier_sha256':FULL_SHA},
      'houston_872':houston,
      'primitive_rigidity':{'checked':len(primitives),'rows':primitives},
      'self_closing_exhaustive_audit':selfrows,
      'bridge_macro_audit':bridges,
      'n14_testbed':n14,
      'ledger_effect':{
       'full_primitive_block_absorption_self_nesting_check':'CLOSED',
       'reason':'its counted portals have minto=2 and last piece full, hence are rigid',
       'previous_candidate_n14_block_gain_withdrawn':False
      },
      'proof_status':{'traditional_proofs':'accompanying note','finite_verifier':'PASS','lean':False,'peer_review':False}
    }
    if args.output: args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','Houston_self_nested':houston['self_nested_chains'],
      'primitive_rigid':len(primitives),'bridge_k14':n14},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
