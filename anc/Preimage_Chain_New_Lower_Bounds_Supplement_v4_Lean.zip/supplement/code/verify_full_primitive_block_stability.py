#!/usr/bin/env python3
"""
Finite standard-library audit for the Full Primitive-Block Stability theorem.

General mathematical results proved in the accompanying note:

1. Endpoint-matching W3-chain capacity:
       2r <= (k-2)(Delta+e),
   where e is the number of full endpoints of the chain.

2. Full primitive-block stability for a non-root component C:
       2d(C) >= (k-2)(m(C)-pi(C)),
   where pi(C)=1 iff minto(C)=2 and the last piece is full.
   Equivalently,
       (k-2)t(C) <= (k-2)D_k pi(C)+(D_k-1)d(C).

3. Strong distinguished-component envelope:
       t_R <= (k-1)(k-2)+(k-1)(K_s-K),
   and hence
       (k-2)t_R+(D_k-1)K
       <= (k-1)(k-2)(K_s+k-2).

4. Layerwise preimage boost:
       Z_s = ceil_+(((k-2)(k-1)!-C_s)/((k-2)D_k)),
       G_s = max(0,Z_s-1-floor(K_s/H_k)),
       Gamma_k = min_s(s+G_s).

This verifier checks the finite local word lemmas, the primitive-ladder W3
antichain, all arithmetic identities, and the pointwise Gamma values through
n=14. It is not a Lean formalization.
"""

from __future__ import annotations

import argparse
import collections
import functools
import itertools
import json
import math
from pathlib import Path
from typing import Any


def ceildiv(a: int, b: int) -> int:
    return (a + b - 1) // b


def rotate(word: tuple[int, ...], amount: int = 1) -> tuple[int, ...]:
    amount %= len(word)
    return word[amount:] + word[:amount]


def canonical_rotation(word: tuple[int, ...]) -> tuple[int, ...]:
    return rotate(word, word.index(0))


def rho2(word: tuple[int, ...]) -> tuple[int, ...]:
    return word[2:] + (word[1], word[0])


def overlap_weight(source: tuple[int, ...], target: tuple[int, ...]) -> int:
    n = len(source)
    for dropped in range(1, n + 1):
        if source[dropped:] == target[: n - dropped]:
            return dropped
    raise AssertionError("empty overlap must work")


def D(k: int) -> int:
    return k * k - 3 * k + 1


def H(k: int) -> int:
    return (k - 1) * (k - 3)


def kappa(k: int) -> int:
    numerator = math.factorial(k - 2) - (k - 2)
    return D(k) * ceildiv(numerator, D(k)) - numerator


def hunter_path_bound(k: int) -> int:
    return (
        math.factorial(k)
        + math.factorial(k - 1)
        + math.factorial(k - 2)
        - 3
        + ceildiv(math.factorial(k - 2) - (k - 2), D(k))
    )


def hunter_string_bound(k: int) -> int:
    return hunter_path_bound(k) + k


def gain_one_upper(k: int) -> int:
    return (
        math.factorial(k)
        + math.factorial(k - 1)
        + math.factorial(k - 2)
        + math.factorial(k - 3)
        + k
        - 4
    )


def piece_support(start: tuple[int, ...], size: int) -> frozenset[tuple[int, ...]]:
    marker = start[-1]
    base = start[:-1]
    return frozenset(
        canonical_rotation((marker,) + rotate(base, offset))
        for offset in range(size)
    )


def piece_end(start: tuple[int, ...], size: int) -> tuple[int, ...]:
    return (start[-1],) + rotate(start[:-1], size - 1)


def exact_w3_successors(start: tuple[int, ...], size: int) -> tuple[tuple[tuple[int, ...], int], ...]:
    endpoint = piece_end(start, size)
    output = []
    for tail in itertools.permutations(endpoint[:3]):
        target_start = endpoint[3:] + tail
        if overlap_weight(endpoint, target_start) != 3:
            raise AssertionError("generated target is not exact W3")
        for target_size in range(1, len(start)):
            output.append((target_start, target_size))
    return tuple(output)


def pattern_exists(k: int, allowed_sizes: tuple[tuple[int, ...], ...]) -> tuple[bool, int]:
    identity = tuple(range(k))
    nodes = 0

    @functools.lru_cache(maxsize=None)
    def support(start: tuple[int, ...], size: int) -> frozenset[tuple[int, ...]]:
        return piece_support(start, size)

    @functools.lru_cache(maxsize=None)
    def successors(start: tuple[int, ...], size: int):
        return exact_w3_successors(start, size)

    def search(position: int, previous, used: frozenset[tuple[int, ...]]) -> bool:
        nonlocal nodes
        nodes += 1
        if position == len(allowed_sizes):
            return True
        if position == 0:
            candidates = [(identity, size) for size in allowed_sizes[0]]
        else:
            candidates = [
                state for state in successors(*previous)
                if state[1] in allowed_sizes[position]
            ]
        for state in candidates:
            state_support = support(*state)
            if state_support & used:
                continue
            if search(position + 1, state, used | state_support):
                return True
        return False

    return search(0, None, frozenset()), nodes


def audit_local_run_lemmas(k: int) -> dict[str, Any]:
    full = k - 1
    unit = k - 2

    pure, pure_nodes = pattern_exists(k, tuple((full,) for _ in range(k - 1)))
    if pure:
        raise AssertionError((k, "k-1 consecutive full pieces exist"))

    unit_two_sided, unit_nodes = pattern_exists(k, ((full,), (unit,), (full,)))
    if unit_two_sided:
        raise AssertionError((k, "unit portal is two-sided"))

    endpoint_rows = []
    for deficit in range(1, k - 1):
        partial = k - 1 - deficit
        before, before_nodes = pattern_exists(
            k, tuple([(full,)] * (k - 2) + [(partial,)])
        )
        after, after_nodes = pattern_exists(
            k, tuple([(partial,)] + [(full,)] * (k - 2))
        )
        if before or after:
            raise AssertionError((k, deficit, "endpoint run too long"))
        endpoint_rows.append({
            "deficit": deficit,
            "before_exists": before,
            "after_exists": after,
            "before_nodes": before_nodes,
            "after_nodes": after_nodes,
        })

    internal_rows = []
    for left_deficit in range(1, k - 1):
        for right_deficit in range(1, k - 1):
            left_size = k - 1 - left_deficit
            right_size = k - 1 - right_deficit
            found, nodes = pattern_exists(
                k,
                tuple([(left_size,)] + [(full,)] * (k - 3) + [(right_size,)]),
            )
            expected = left_deficit + right_deficit >= k - 1
            if found != expected:
                raise AssertionError((k, left_deficit, right_deficit, found, expected))
            internal_rows.append({
                "left_deficit": left_deficit,
                "right_deficit": right_deficit,
                "exists": found,
                "expected": expected,
                "nodes": nodes,
            })

    return {
        "k": k,
        "pure_full_maximum": k - 2,
        "pure_full_search_nodes": pure_nodes,
        "unit_portal_two_sided": False,
        "unit_portal_search_nodes": unit_nodes,
        "endpoint_rows": endpoint_rows,
        "internal_threshold_rows": internal_rows,
        "derived_endpoint_matching_bound": "2r <= (k-2)(Delta+e)",
    }


def primitive_specs(k: int, defect: int):
    piece_count = k - 2 - defect
    marker = k - 1
    anchor = k - 3
    orbit = tuple(range(k - 3)) + (k - 2,)
    specs = [(tuple(range(k)), k - 2)]
    specs += [
        (rotate(orbit, shift) + (anchor, marker), k - 1)
        for shift in range(piece_count - 1)
    ]
    return specs


def primitive_support(k: int, defect: int, relabel: tuple[int, ...] | None = None):
    if relabel is None:
        relabel = tuple(range(k))
    support = set()
    for start, size in primitive_specs(k, defect):
        transformed = tuple(relabel[symbol] for symbol in start)
        support.update(piece_support(transformed, size))
    return support


def primitive_head(k: int, defect: int) -> tuple[int, ...]:
    start, size = primitive_specs(k, defect)[-1]
    return piece_end(start, size)


def primitive_last_full_support(k: int, defect: int):
    start, size = primitive_specs(k, defect)[-1]
    if size != k - 1:
        raise AssertionError("primitive ladder must end in a full piece")
    return set(piece_support(start, size))


def audit_primitive_antichain(k: int) -> dict[str, Any]:
    defects = range(k - 3)
    components = {d: primitive_support(k, d) for d in defects}
    last_full_supports = {d: primitive_last_full_support(k, d) for d in defects}
    rows = []
    minimum = 10**9
    maximum = 0
    minimum_last_full = 10**9
    tests = 0

    for source_defect in defects:
        head = primitive_head(k, source_defect)
        target_starts = [head[3:] + permutation for permutation in itertools.permutations(head[:3])]
        if not all(overlap_weight(head, start) == 3 for start in target_starts):
            raise AssertionError("W3 start generation drift")

        for target_defect in defects:
            counts = []
            for target_start in target_starts:
                target = primitive_support(k, target_defect, target_start)
                intersection = len(components[source_defect] & target)
                boundary_intersection = len(last_full_supports[source_defect] & target)
                if intersection < 2 or boundary_intersection < 2:
                    raise AssertionError((
                        k, source_defect, target_defect, target_start,
                        intersection, boundary_intersection,
                    ))
                counts.append(intersection)
                minimum = min(minimum, intersection)
                maximum = max(maximum, intersection)
                minimum_last_full = min(minimum_last_full, boundary_intersection)
                tests += 1
            rows.append({
                "source_defect": source_defect,
                "target_defect": target_defect,
                "intersection_counts": counts,
                "minimum": min(counts),
            })

    return {
        "k": k,
        "primitive_types": k - 3,
        "candidate_W3_transitions": tests,
        "minimum_intersection": minimum,
        "minimum_intersection_from_source_last_full_piece": minimum_last_full,
        "maximum_intersection": maximum,
        "all_disjoint_transitions_zero": True,
        "rows": rows,
    }


def layer_data(k: int, s: int) -> dict[str, int]:
    dk = D(k)
    hk = H(k)
    K_s = kappa(k) + s * dk
    total_cycles = math.factorial(k - 1)

    # Strong distinguished-component envelope in (k-2)-weighted units.
    root_constant = (k - 1) * (k - 2) ** 2 + (dk + 1) * K_s
    denominator = (k - 2) * dk
    numerator = (k - 2) * total_cycles - root_constant
    portal_components = max(0, ceildiv(numerator, denominator)) if numerator > 0 else 0
    absorbers = K_s // hk
    gap = max(0, portal_components - 1 - absorbers)

    return {
        "s": s,
        "D": dk,
        "H": hk,
        "K_s": K_s,
        "root_constant": root_constant,
        "portal_components": portal_components,
        "high_minto_absorbers": absorbers,
        "gap": gap,
        "objective": s + gap,
    }


def gamma(k: int):
    best = None
    rows_checked = 0
    s = 0
    while True:
        row = layer_data(k, s)
        rows_checked += 1
        if best is None or row["objective"] < best["objective"]:
            best = row
        if row["gap"] == 0 and s >= best["objective"]:
            break
        s += 1
        if s > 20_000_000:
            raise AssertionError("layer minimization did not terminate")
    return best["objective"], best, rows_checked


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    local_rows = [audit_local_run_lemmas(k) for k in range(5, 15)]
    antichain_rows = [audit_primitive_antichain(k) for k in range(5, 21)]

    total_antichain_tests = sum(row["candidate_W3_transitions"] for row in antichain_rows)
    if total_antichain_tests != 6 * sum((k - 3) ** 2 for k in range(5, 21)):
        raise AssertionError("primitive antichain test census drift")

    algebra_rows = []
    for k in range(5, 101):
        dk = D(k)
        if dk != (k - 1) * (k - 2) - 1:
            raise AssertionError("D identity drift")
        if dk - 1 != (k - 1) * (k - 2) - 2:
            raise AssertionError("D-1 identity drift")
        if k * k - 5 * k + 4 != (k - 1) * (k - 4):
            raise AssertionError("block-stability coefficient drift")

        # The root proof uses D-2(k-2)=k^2-5k+5 >=0.
        root_margin = dk - 2 * (k - 2)
        if root_margin < 0:
            raise AssertionError("root envelope sign failure")

        algebra_rows.append({
            "k": k,
            "D": dk,
            "D_minus_1": dk - 1,
            "H": H(k),
            "nonroot_affine": (
                "(k-2)t <= (k-2)D*pi + (D-1)d"
            ),
            "root_margin_D_minus_2(k-2)": root_margin,
        })

    expected_gamma = {
        5: 0,
        6: 0,
        7: 4,
        8: 15,
        9: 80,
        10: 505,
        11: 3669,
        12: 30263,
        13: 279300,
        14: 2852497,
    }

    pointwise = []
    for k in range(5, 15):
        value, best, checked = gamma(k)
        if value != expected_gamma[k]:
            raise AssertionError(("Gamma drift", k, value, expected_gamma[k]))
        pointwise.append({
            "k": k,
            "Hunter_string_bound": hunter_string_bound(k),
            "Gamma_block": value,
            "candidate_bound": hunter_string_bound(k) + value,
            "gain_one_upper": gain_one_upper(k) if k >= 8 else None,
            "minimizing_layer": best,
            "layers_checked": checked,
            "factorial_scale_(k-4)!": math.factorial(max(k - 4, 0)),
            "Gamma_over_(k-4)!": value / math.factorial(max(k - 4, 0)),
        })

    gamma14, best14, layers14 = gamma(14)
    hunter14 = hunter_string_bound(14)
    upper14 = gain_one_upper(14)
    candidate14 = hunter14 + gamma14

    n14 = {
        "k": 14,
        "D": D(14),
        "D_minus_1": D(14) - 1,
        "H": H(14),
        "kappa": kappa(14),
        "total_rotation_classes": math.factorial(13),
        "Hunter_string_bound": hunter14,
        "Gamma_block": gamma14,
        "candidate_string_lower": candidate14,
        "gain_one_upper": upper14,
        "remaining_gap": upper14 - candidate14,
        "minimizing_layer": best14,
        "layers_checked": layers14,
        "official_layer": layer_data(14, 0),
        "layer_before_minimum": layer_data(14, best14["s"] - 1),
        "minimum_layer": best14,
    }

    report = {
        "general_theorems": {
            "endpoint_matching_capacity": "2r <= (k-2)(Delta+e)",
            "full_block_stability": (
                "2d >= (k-2)(m-pi), equivalently "
                "(k-2)t <= (k-2)D*pi+(D-1)d"
            ),
            "strong_root_envelope": (
                "t_R <= (k-1)(k-2)+(k-1)(K_s-K)"
            ),
            "weighted_root_envelope": (
                "(k-2)t_R+(D-1)K <= "
                "(k-1)(k-2)^2+(D+1)K_s"
            ),
            "primitive_ladder_antichain": (
                "T_{k,d} cannot precede T_{k,e} through an exact W3 seam"
            ),
            "layer_boost": (
                "Z_s=ceil_+(((k-2)(k-1)!-C_s)/((k-2)D)); "
                "G_s=max(0,Z_s-1-floor(K_s/H)); Gamma=min_s(s+G_s)"
            ),
            "asymptotic_order": (
                "Gamma_k=Omega((k-1)!/k^3)=Omega((k-4)!)"
            ),
        },
        "local_run_audit": local_rows,
        "primitive_antichain_audit": {
            "degrees": [5, 20],
            "tests": total_antichain_tests,
            "minimum_intersection": min(row["minimum_intersection"] for row in antichain_rows),
            "minimum_intersection_from_source_last_full_piece": min(
                row["minimum_intersection_from_source_last_full_piece"]
                for row in antichain_rows
            ),
            "rows": antichain_rows,
        },
        "algebra_audit": algebra_rows,
        "pointwise_table": pointwise,
        "n14_testbed": n14,
        "proof_status": {
            "traditional_general_proof": "in accompanying note",
            "finite_verifier": "PASS",
            "Lean_formalization": False,
            "second_independent_implementation": False,
            "external_peer_review": False,
            "recommended_label": "candidate new general computer-assisted lower-bound theorem",
        },
    }

    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")

    print(json.dumps({
        "status": "PASS",
        "primitive_antichain_tests": total_antichain_tests,
        "pointwise_Gamma": {str(row["k"]): row["Gamma_block"] for row in pointwise},
        "n14": {
            "Hunter_bound": hunter14,
            "Gamma_block": gamma14,
            "candidate_lower": candidate14,
            "upper": upper14,
            "remaining_gap": upper14 - candidate14,
        },
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
