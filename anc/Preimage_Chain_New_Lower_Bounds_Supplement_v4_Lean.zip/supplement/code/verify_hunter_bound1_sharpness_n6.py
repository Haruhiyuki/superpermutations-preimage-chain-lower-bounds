#!/usr/bin/env python3
"""Independent verifier for the n=6 Hunter Bound-1 sharpness certificate."""

from __future__ import annotations
import argparse
import collections
from fractions import Fraction
import gzip
import itertools
import json
import math
from pathlib import Path


def rotate(word, amount=1):
    word = tuple(word)
    amount %= len(word)
    return word[amount:] + word[:amount]


def canonical_rotation(word):
    word = tuple(word)
    return min(rotate(word, amount) for amount in range(len(word)))


def overlap_weight(source, target):
    source = tuple(source)
    target = tuple(target)
    n = len(source)
    for dropped in range(1, n + 1):
        if source[dropped:] == target[: n - dropped]:
            return dropped
    raise AssertionError


def held_karp(cost):
    n = len(cost)
    full = (1 << n) - 1
    infinity = 10**9
    dp = [dict() for _ in range(1 << n)]
    parent = {}
    for vertex in range(n):
        dp[1 << vertex][vertex] = 0
    for mask in range(1 << n):
        for last, value in list(dp[mask].items()):
            for nxt in range(n):
                if mask & (1 << nxt):
                    continue
                next_mask = mask | (1 << nxt)
                next_value = value + cost[last][nxt]
                if next_value < dp[next_mask].get(nxt, infinity):
                    dp[next_mask][nxt] = next_value
                    parent[(next_mask, nxt)] = (mask, last)
    end = min(dp[full], key=dp[full].get)
    value = dp[full][end]
    order = []
    state = (full, end)
    while True:
        order.append(state[1])
        if state[0] == 1 << state[1]:
            break
        state = parent[state]
    order.reverse()
    return value, order


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--certificate",
        type=Path,
        default=Path(__file__).resolve().parent
        / "hunter_bound1_sharpness_n6_certificate.json.gz",
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    with gzip.open(args.certificate, "rt", encoding="utf-8") as handle:
        certificate = json.load(handle)

    assert certificate["format"] == "hunter-bound1-sharpness-n6-v1"
    assert certificate["n"] == 6
    components = certificate["components"]
    assert len(components) == 8

    universe = set(itertools.permutations(range(6)))
    owned = set()
    paths = []
    verified = []

    for index, record in enumerate(components):
        path = tuple(tuple(vertex) for vertex in record["path"])
        vertices = set(path)
        assert len(path) == record["vertex_count"]
        assert len(vertices) == len(path)
        assert vertices <= universe
        assert not (owned & vertices)
        owned |= vertices

        positions = {vertex: position for position, vertex in enumerate(path)}
        for position, (source, target) in enumerate(zip(path, path[1:])):
            if overlap_weight(source, target) >= 2:
                assert not (
                    position < positions.get(rotate(source), len(path))
                ), ("early exit", index, position)
        assert rotate(path[-1]) in positions, ("not strongly exitless", index)

        path_weight = sum(
            overlap_weight(source, target)
            for source, target in zip(path, path[1:])
        )
        minto = min(
            overlap_weight(source, path[0])
            for source in universe - vertices
        )
        pvalue = 1 + minto + path_weight
        rotation_classes = {canonical_rotation(vertex) for vertex in path}

        assert path_weight == record["weight"]
        assert minto == record["minto"]
        assert pvalue == record["pvalue"]
        assert len(rotation_classes) == record["cycle_count"]
        assert len(path) == 6 * len(rotation_classes)

        verified.append(
            {
                "vertex_count": len(path),
                "cycle_count": len(rotation_classes),
                "weight": path_weight,
                "minto": minto,
                "pvalue": pvalue,
            }
        )
        paths.append(path)

    assert owned == universe

    component_count = len(components)
    total_weight = sum(item["weight"] for item in verified)
    mintos = [item["minto"] for item in verified]
    min_through = sum(mintos) - max(mintos)
    bound1 = component_count - 1 + min_through + total_weight
    assert bound1 == 863

    census = collections.Counter(item["vertex_count"] for item in verified)
    assert dict(census) == {114: 4, 108: 2, 24: 2}

    exact_lower = Fraction(16379, 19)
    assert math.ceil(exact_lower) == 863

    # Exact minimum direct concatenation for these fixed oriented paths.
    n = len(paths)
    direct = [[10**6] * n for _ in range(n)]
    for left in range(n):
        for right in range(n):
            if left != right:
                direct[left][right] = overlap_weight(
                    paths[left][-1], paths[right][0]
                )
    direct_connectors, direct_order = held_karp(direct)
    direct_weight = total_weight + direct_connectors

    # Exact minimum over the canonical Hunter unwinding family.
    unwind = [[10**6] * n for _ in range(n)]
    for left in range(n):
        first_left = paths[left][0]
        second_left = paths[left][1]
        first_edge = overlap_weight(first_left, second_left)
        for right in range(n):
            if left != right:
                unwind[left][right] = (
                    overlap_weight(first_left, paths[right][0])
                    + overlap_weight(paths[right][-1], second_left)
                    - first_edge
                )
    unwind_extra, unwind_order = held_karp(unwind)
    unwind_weight = total_weight + unwind_extra

    report = {
        "claim": "Hunter Bound-1 objective 863 is attained at n=6.",
        "components": verified,
        "component_size_census": dict(sorted(census.items())),
        "number_components": component_count,
        "total_component_weight": total_weight,
        "minto_values": mintos,
        "MinThrough": min_through,
        "Bound1": bound1,
        "corresponding_string_lower_value": bound1 + 6,
        "arithmetic_lower_target": {
            "fraction": "16379/19",
            "decimal": float(exact_lower),
            "ceiling": math.ceil(exact_lower),
        },
        "fixed_certificate_connection_checks": {
            "minimum_direct_concatenation_path_weight": direct_weight,
            "minimum_direct_concatenation_string_length": direct_weight + 6,
            "direct_order": direct_order,
            "minimum_canonical_unwinding_path_weight": unwind_weight,
            "minimum_canonical_unwinding_string_length": unwind_weight + 6,
            "unwind_order": unwind_order,
        },
    }

    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
