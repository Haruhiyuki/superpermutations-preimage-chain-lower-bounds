#!/usr/bin/env python3
r"""
Independent finite transcription audit for the preimage-chain component
matching theorem.

This checker does not import the main preimage-chain verifier.  It reconstructs
Hunter's transform F, the auxiliary graph D_P, its path/cycle decomposition,
and the source/target component maps from the definitions.

It checks:
  * every one of the 6! = 720 Hamilton paths on S_3;
  * the 19 archived order-four cut-profile witnesses;
  * 4096 deterministic pseudorandom Hamilton paths on S_4.

For I=0 it verifies the two bijections
  paths(D_P) -> Comp(F(P)) \ {last-source component},
  paths(D_P) -> Comp(F(P)) \ {root component}.
For I=1 it verifies the source bijection onto all components and the target
bijection onto the non-root components plus the terminal symbol star.

The arbitrary-k theorem is proved mathematically in the manuscript; this is an
independent finite audit of its formal transcription, not a proof assistant.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import itertools
import json
import random
from pathlib import Path
from typing import Any


def rotate(word: tuple[int, ...], amount: int = 1) -> tuple[int, ...]:
    amount %= len(word)
    return word[amount:] + word[:amount]


def rho(word: tuple[int, ...]) -> tuple[int, ...]:
    return rotate(word, 1)


def rho_inv(word: tuple[int, ...]) -> tuple[int, ...]:
    return rotate(word, -1)


def canonical_rotation(word: tuple[int, ...]) -> tuple[int, ...]:
    return min(rotate(word, amount) for amount in range(len(word)))


def reconstruct(path: tuple[tuple[int, ...], ...]) -> dict[str, Any]:
    n = len(path[0])
    universe = tuple(itertools.permutations(range(n)))
    if len(path) != len(universe) or set(path) != set(universe):
        raise AssertionError("not a Hamilton path on S_n")

    position = {vertex: index for index, vertex in enumerate(path)}
    path_edges = {
        (path[index], path[index + 1])
        for index in range(len(path) - 1)
    }
    successor = {
        path[index]: path[index + 1]
        for index in range(len(path) - 1)
    }
    predecessor = {
        path[index + 1]: path[index]
        for index in range(len(path) - 1)
    }

    classes: dict[tuple[int, ...], list[tuple[int, ...]]] = (
        collections.defaultdict(list)
    )
    for vertex in universe:
        classes[canonical_rotation(vertex)].append(vertex)

    C0 = set()
    Cm1 = set()
    for cycle in classes.values():
        first = min(cycle, key=position.__getitem__)
        C0.add(first)
        Cm1.add(rho_inv(first))

    S = {
        vertex
        for vertex in universe
        if vertex not in Cm1
        and (vertex, rho(vertex)) not in path_edges
    }

    E1 = {edge for edge in path_edges if edge[0] in S}
    added = {(vertex, rho(vertex)) for vertex in S}
    step1 = (path_edges - E1) | added
    indegree_step1 = collections.Counter(target for _, target in step1)
    doubles = {
        vertex for vertex, degree in indegree_step1.items() if degree == 2
    }
    E2 = {edge for edge in path_edges if edge[1] in doubles}
    X = step1 - E2

    incoming: dict[tuple[int, ...], list[tuple[int, ...]]] = (
        collections.defaultdict(list)
    )
    outgoing: dict[tuple[int, ...], list[tuple[int, ...]]] = (
        collections.defaultdict(list)
    )
    undirected: dict[tuple[int, ...], set[tuple[int, ...]]] = (
        collections.defaultdict(set)
    )
    for source, target in X:
        outgoing[source].append(target)
        incoming[target].append(source)
        undirected[source].add(target)
        undirected[target].add(source)

    components = []
    component_of: dict[tuple[int, ...], int] = {}
    seen = set()
    for vertex in universe:
        if vertex in seen:
            continue
        stack = [vertex]
        seen.add(vertex)
        component = set()
        while stack:
            current = stack.pop()
            component.add(current)
            for neighbour in undirected[current]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    stack.append(neighbour)
        tails = [item for item in component if not incoming[item]]
        heads = [item for item in component if not outgoing[item]]
        if len(tails) != 1 or len(heads) != 1:
            raise AssertionError(("component is not a directed path", tails, heads))
        index = len(components)
        for item in component:
            component_of[item] = index
        components.append(
            {
                "vertices": component,
                "tail": tails[0],
                "head": heads[0],
            }
        )

    # D_P: u -> v iff the P-edge u -> rho(v) exists, with u,v in S.
    D_successor: dict[tuple[int, ...], tuple[int, ...]] = {}
    D_indegree: collections.Counter[tuple[int, ...]] = collections.Counter()
    for u in S:
        if u not in successor:
            continue
        v = rho_inv(successor[u])
        if v in S and successor[u] == rho(v):
            D_successor[u] = v
            D_indegree[v] += 1

    starts = [vertex for vertex in S if D_indegree[vertex] == 0]
    visited = set()
    chains = []

    for start in starts:
        slots = []
        current = start
        while current not in visited:
            visited.add(current)
            slots.append(current)
            if current not in D_successor:
                break
            current = D_successor[current]

        # Source head: predecessor of rho(start); it must exist and be the
        # unique head of its X-component.
        target_of_initial = rho(start)
        if target_of_initial not in predecessor:
            raise AssertionError("D-path start has no P-predecessor")
        source_head = predecessor[target_of_initial]
        source_component = component_of[source_head]
        if components[source_component]["head"] != source_head:
            raise AssertionError("D-path does not start at an X-head")
        if source_head in S:
            raise AssertionError("D-path source head unexpectedly lies in S")
        if (source_head, target_of_initial) not in E2:
            raise AssertionError("initial edge is not in E2")

        end = slots[-1]
        if end == path[-1]:
            target_component = None
            terminal = True
        else:
            terminal = False
            target_tail = successor[end]
            target_component = component_of[target_tail]
            if components[target_component]["tail"] != target_tail:
                raise AssertionError("D-path does not end at an X-tail")
            if (end, target_tail) not in E1:
                raise AssertionError("exit edge is not in E1")
            if end in components[target_component]["vertices"]:
                raise AssertionError("exit slot lies inside target component")

        chains.append(
            {
                "slots": tuple(slots),
                "source": source_component,
                "target": target_component,
                "terminal": terminal,
            }
        )

    cycles = []
    for vertex in S:
        if vertex in visited:
            continue
        cycle = []
        current = vertex
        while current not in visited:
            visited.add(current)
            cycle.append(current)
            if current not in D_successor:
                raise AssertionError("unvisited D-component is not a cycle")
            current = D_successor[current]
        if current != vertex:
            raise AssertionError("D-cycle closes at the wrong vertex")
        cycles.append(tuple(cycle))

    if visited != S:
        raise AssertionError("D decomposition did not cover S")

    I = int(path[-1] in S)
    root_component = component_of[path[0]]
    last_component = component_of[path[-1]]
    all_components = set(range(len(components)))
    sources = [record["source"] for record in chains]
    targets = [record["target"] for record in chains if not record["terminal"]]
    terminals = [record for record in chains if record["terminal"]]

    if len(sources) != len(set(sources)):
        raise AssertionError("two D-paths share a source component")
    if len(targets) != len(set(targets)):
        raise AssertionError("two D-paths share a target component")

    if I == 0:
        if terminals:
            raise AssertionError("I=0 but a terminal chain exists")
        if set(sources) != all_components - {last_component}:
            raise AssertionError("source bijection failed in I=0 case")
        if set(targets) != all_components - {root_component}:
            raise AssertionError("target bijection failed in I=0 case")
        if len(chains) != len(components) - 1:
            raise AssertionError("wrong chain count in I=0 case")
    else:
        if len(terminals) != 1:
            raise AssertionError("I=1 does not have exactly one terminal chain")
        if set(sources) != all_components:
            raise AssertionError("source bijection failed in I=1 case")
        if set(targets) != all_components - {root_component}:
            raise AssertionError("target bijection failed in I=1 case")
        if len(chains) != len(components):
            raise AssertionError("wrong chain count in I=1 case")

    # D-cycles have no boundary E2/exit edges.  Every cycle edge is an E1
    # edge whose source lies in S and whose target is rho(next slot).
    for cycle in cycles:
        for index, u in enumerate(cycle):
            v = cycle[(index + 1) % len(cycle)]
            edge = (u, rho(v))
            if edge not in E1:
                raise AssertionError("D-cycle edge is not internal E1")
            if edge in E2:
                raise AssertionError("D-cycle edge unexpectedly belongs to E2")

    return {
        "n": n,
        "components": len(components),
        "S_size": len(S),
        "chains": len(chains),
        "cycles": len(cycles),
        "I": I,
        "self_nested_chains": sum(
            1
            for record in chains
            if record["target"] is not None
            and record["source"] == record["target"]
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    directory = Path(__file__).resolve().parent.parent
    parser.add_argument(
        "--n4-witnesses",
        type=Path,
        default=directory / "data/n4_cut_profile_witnesses.json.gz",
    )
    parser.add_argument("--random-n4", type=int, default=4096)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    n3_universe = tuple(itertools.permutations(range(3)))
    n3_rows = []
    for ordering in itertools.permutations(n3_universe):
        n3_rows.append(reconstruct(tuple(ordering)))

    with gzip.open(args.n4_witnesses, "rt", encoding="utf-8") as handle:
        archived = json.load(handle)
    n4_witness_rows = []
    for key in sorted(archived, key=int):
        path = tuple(tuple(vertex) for vertex in archived[key]["path"])
        n4_witness_rows.append(reconstruct(path))

    rng = random.Random(20260803)
    n4_universe = list(itertools.permutations(range(4)))
    n4_random_rows = []
    for _ in range(args.random_n4):
        rng.shuffle(n4_universe)
        n4_random_rows.append(reconstruct(tuple(n4_universe)))

    all_rows = n3_rows + n4_witness_rows + n4_random_rows
    report = {
        "status": "PASS",
        "theorem_audited": (
            "preimage-chain source/target component matching, including "
            "the I=0 and I=1 bijections and self-nesting capacity one"
        ),
        "implementation": (
            "independent reconstruction; does not import the main preimage checker"
        ),
        "coverage": {
            "all_S3_Hamilton_paths": len(n3_rows),
            "archived_S4_witnesses": len(n4_witness_rows),
            "deterministic_random_S4_paths": len(n4_random_rows),
            "random_seed": 20260803,
        },
        "aggregate": {
            "instances": len(all_rows),
            "I_histogram": dict(
                sorted(collections.Counter(row["I"] for row in all_rows).items())
            ),
            "component_count_histogram": dict(
                sorted(
                    collections.Counter(
                        row["components"] for row in all_rows
                    ).items()
                )
            ),
            "instances_with_D_cycles": sum(
                1 for row in all_rows if row["cycles"]
            ),
            "instances_with_self_nesting": sum(
                1 for row in all_rows if row["self_nested_chains"]
            ),
        },
        "proof_status": {
            "arbitrary_k_theorem": "traditional proof in the manuscript",
            "finite_transcription_audit": "PASS",
            "Lean_formalization": False,
        },
    }

    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "status": "PASS",
                "instances": report["aggregate"]["instances"],
                "I_histogram": report["aggregate"]["I_histogram"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
