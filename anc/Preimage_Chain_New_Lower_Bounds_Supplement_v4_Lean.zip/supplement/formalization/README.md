# Lean 4 formalization release record

This directory records the completed formal proof layer used by the manuscript.

- Lean: **4.31.0**
- Repository: `https://github.com/Haruhiyuki/superpermutations-preimage-chain-lower-bounds`
- Formalization source snapshot: `a3852f0de2d84b99cc65d4c281e86892b5f6e911`
- Hunter baseline: `d45222190031d162feb1f6f3cf5fe2d11fab726d`

## Final public theorems

- `PreimageChain.actual_reduced_pathwise_bound_closed`
- `PreimageChain.pathwise_new_bound_closed`
- `PreimageChain.superperm_new_bound_closed`
- `PreimageChain.superperm_numerical_bounds_closed`

## Audit outcome

- `lake --rehash build`: PASS, 8714 jobs
- `lake env lean AxiomCheck.lean`: PASS
- active `sorry`, `admit`, project-local `axiom`: none
- axioms reported for final theorems: `propext`, `Classical.choice`, `Quot.sound`

`key_sources/` contains the final small trust-boundary modules and the two terminal-case payment implementations. `logs/` contains the release build and axiom-audit output. `source_reconstruction/` contains the exact tracked source tree at the commit above.
