# Formalization source snapshot

`Superpermutation_release_reconstruction/` is the exact tracked source tree exported from

`https://github.com/Haruhiyuki/superpermutations-preimage-chain-lower-bounds`

at commit

`a3852f0de2d84b99cc65d4c281e86892b5f6e911`.

The snapshot contains the complete project sources, pinned Lake manifest, Lean toolchain,
reproduction documentation, axiom audit, citation metadata, and CC BY 4.0 license. Build caches and
Git metadata are intentionally excluded. Hunter and mathlib are resolved at the revisions recorded
by the Lake manifest.
