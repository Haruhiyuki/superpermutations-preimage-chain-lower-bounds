#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CODE = ROOT / "code"
DATA = ROOT / "data"


def run(args: list[str], output: Path, frozen_report: Path) -> dict:
    command = [sys.executable, *args, "--output", str(output)]
    completed = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode:
        print(completed.stdout)
        print(completed.stderr, file=sys.stderr)
        raise SystemExit(completed.returncode)
    regenerated = output.read_bytes()
    frozen = frozen_report.read_bytes()
    if regenerated != frozen:
        raise SystemExit(
            f"regenerated report differs byte-for-byte: {frozen_report.relative_to(ROOT)}"
        )
    return json.loads(regenerated.decode("utf-8"))


with tempfile.TemporaryDirectory(prefix="preimage-chain-audit-") as td_raw:
    td = Path(td_raw)

    reduced = run(
        [str(CODE / "verify_reduced_weight2_normal_form.py")],
        td / "reduced.json",
        ROOT / "reports/reduced_weight2_normal_form_report.json",
    )
    sharp = run(
        [
            str(CODE / "verify_hunter_bound1_sharpness_n6.py"),
            "--certificate",
            str(DATA / "hunter_bound1_sharpness_n6_certificate.json.gz"),
        ],
        td / "sharp.json",
        ROOT / "reports/hunter_bound1_sharpness_n6_report.json",
    )
    preimage = run(
        [
            str(CODE / "verify_preimage_chain_bound_n6.py"),
            "--sharp-certificate",
            str(DATA / "hunter_bound1_sharpness_n6_certificate.json.gz"),
            "--n4-witnesses",
            str(DATA / "n4_cut_profile_witnesses.json.gz"),
        ],
        td / "preimage.json",
        ROOT / "reports/preimage_chain_bound_n6_report.json",
    )
    matching = run(
        [
            str(CODE / "verify_preimage_component_matching.py"),
            "--n4-witnesses",
            str(DATA / "n4_cut_profile_witnesses.json.gz"),
        ],
        td / "matching.json",
        ROOT / "reports/preimage_component_matching_report.json",
    )
    edgecases = run(
        [str(CODE / "verify_revision_edge_cases.py")],
        td / "edgecases.json",
        ROOT / "reports/revision_edge_cases_report.json",
    )
    full = run(
        [str(CODE / "verify_full_primitive_block_stability.py")],
        td / "full.json",
        ROOT / "reports/full_primitive_block_stability_report.json",
    )
    selfnest = run(
        [
            str(CODE / "verify_self_nesting_bridge_macro_theory.py"),
            "--base",
            str(CODE / "verify_preimage_chain_bound_n6.py"),
            "--full-stability",
            str(CODE / "verify_full_primitive_block_stability.py"),
        ],
        td / "selfnest.json",
        ROOT / "reports/self_nesting_bridge_macro_theory_report.json",
    )

    assert reduced["status"] == "PASS"
    assert sharp["Bound1"] == 863
    assert preimage["bound1_sharp_X"]["PairGap"] == 6
    assert preimage["houston_872"]["PairGap"] == 0
    assert matching["status"] == "PASS"
    assert matching["coverage"]["all_S3_Hamilton_paths"] == 720
    assert matching["coverage"]["archived_S4_witnesses"] == 19
    assert matching["coverage"]["deterministic_random_S4_paths"] == 4096
    assert edgecases["status"] == "PASS"
    assert edgecases["rate_defect_domain"]["order_five_spanning_path_scalars"]["signed_deviation"] == -17
    assert edgecases["k5_bridge_ambiguity"]["count"] == 3
    assert full["n14_testbed"]["candidate_string_lower"] == 93890256441
    assert selfnest["status"] == "PASS"
    assert selfnest["houston_872"]["self_nested_chains"] == 25

claims = json.loads((ROOT / "paper_claims.json").read_text(encoding="utf-8"))
assert claims["numerical_lower_bounds"]["14"] == 93890256441

subprocess.run(
    [sys.executable, str(ROOT / "run_quick_audit.py")],
    check=True,
    cwd=ROOT,
)
print(json.dumps({"status": "PASS", "mode": "full reconstruction"}, indent=2))
