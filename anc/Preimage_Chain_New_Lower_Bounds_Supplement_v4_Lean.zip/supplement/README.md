# Preimage-Chain Corrections — Lean-formalized release supplement

Artifact version: **4.0.1-lean-formalized-release**

This supplement accompanies

> *Preimage-Chain Corrections, Primitive-Block Rigidity, and New Lower Bounds for Superpermutations*.

The release keeps three complementary verification layers distinct:

1. **Pinned external Lean baseline.** Hunter–Raudvere definitions and lower-bound infrastructure are fixed at commit `d45222190031d162feb1f6f3cf5fe2d11fab726d`.
2. **Lean 4.31.0 formalization of the new main proof chain.** The public repository is `https://github.com/Haruhiyuki/superpermutations-preimage-chain-lower-bounds`, and the exact source snapshot is commit `a3852f0de2d84b99cc65d4c281e86892b5f6e911`. The final public theorems are listed in `formalization/README.md`.
3. **Deterministic finite reconstruction.** The Python programs in `code/` independently audit finite certificates, local word transcriptions, component matching, and exact numerical tables. They use only the Python standard library.

## Quick finite audit

```bash
python run_quick_audit.py
```

## Full finite reconstruction

```bash
python run_full_audit.py
```

## Lean release audit

The canonical formal release was checked with:

```bash
lake --rehash build
lake env lean AxiomCheck.lean
rg -n '\bsorry\b|\badmit\b|^\s*axiom\b' \
  --glob '*.lean' --glob '!vendor/**' --glob '!proof-progress/**' .
```

The recorded results and selected final proof sources are under `formalization/`. The full rehashed build completed successfully with 8714 jobs. The final exported theorems use only `propext`, `Classical.choice`, and `Quot.sound`; the project adds no axiom and contains no active `sorry` or `admit`.

## Contents

- `code/`, `data/`, `reports/`: deterministic finite audit and frozen outputs.
- `formalization/`: release metadata, selected final Lean sources, final build logs, axiom audit, and a source-reconstruction snapshot.
- `paper_claims.json`: machine-readable claims and nonclaims.
- `CLAIM_MAP.md`: manuscript claim-to-verification map.
- `REPRODUCIBILITY.md`: exact commands and trust boundary.
- `docs/EXTERNAL_BASELINE.md`: pinned external Lean inputs.
- `MANIFEST.json`: byte count and SHA-256 for every frozen file.

## Explicit nonclaims

The release does **not** claim `S(6)=872`, `S(6)≥875`, a general `Ω((k-3)!)` correction, independent peer review, or an unrelated second formalization. The deterministic Python PASS reports are independent finite audits; the arbitrary-order proof certification is supplied by the Lean development identified above.
